watch-simulator
===============

This lets you protype apps for the Apple Watch. It is a template app that runs on an iPhone or iPad. Run it in Xcode and you'll get a sample counting app. 

![Apple Watch simulator on iPhone 6](http://happy.watch/s/apple-watch-simulator-on-iphone-6.jpg)

Just another way to be ahead of the game. Can't wait to see what you build with it.

![Apple Watch simulator in Xcode](http://happy.watch/s/watch-simulator-xcode.png)

A demo app built with the simulator: *Heartbeat*

[![Play Video on YouTube](http://happy.watch/s/heartbeat-apple-watch-app-youtube-video.jpg)](http://bit.ly/heartbeat-video)

See the [code for Heartbeat on GitHub](https://github.com/happywatch/heartbeat).
